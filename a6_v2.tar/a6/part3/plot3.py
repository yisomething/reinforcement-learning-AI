import os
from matplotlib import pyplot as plt
import numpy as np
import mpl_toolkits.mplot3d

filename = 'value'
file=open(filename,"r")
processed_data = file.read().splitlines()
fig = plt.figure()
ax = plt.axes(projection = '3d')

if os.path.exists(filename):

  x = np.linspace(-1.2, 0.5, 50)
  y = np.linspace(-0.07,0.07,50)

  x1, y1 = np.meshgrid(x, y)

  data = [ ]
for i in processed_data:
	temp = i.split(" ")[:-1]
	temp = list(map(lambda x:float(x),temp))
	data.append(temp)
	z = np.array(data)
  
ax.set_xticks([-1.2, 0.5])
ax.set_yticks([0.07, -0.07])
ax.set_zticks([0, np.max(data)])
ax.set_ylabel('Velocity')
ax.set_xlabel('Position')
ax.set_zlabel('Cost To Go')
ax.plot_surface(x1,y1,z)
plt.savefig('part3.png')
plt.show()
